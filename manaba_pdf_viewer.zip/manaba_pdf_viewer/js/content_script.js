console.log("PDFプレビュー拡張機能: コンテンツスクリプトが読み込まれました。");

/**
 * ページ内のPDFリンクを探してボタンを追加する関数
 */
function addPreviewButtons() {
  console.log("PDFリンクを探しています...");

  const fileWrappers = document.querySelectorAll('div.file'); // ★ここはご自身のセレクタに

  console.log(`${fileWrappers.length} 個の 'div.file' が見つかりました。`);

  fileWrappers.forEach(wrapper => {
    const link = wrapper.querySelector('a');

    if (link && (link.href.endsWith('.pdf') || link.href.includes('pdf'))) {

      if (wrapper.dataset.previewButtonAdded) {
        return;
      }

      console.log(`PDFリンク発見: ${link.href}`);

      const previewButton = document.createElement('button');
      previewButton.textContent = 'プレビュー';
      previewButton.className = 'pdf-preview-button';

      previewButton.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        const pdfUrl = link.href;
        console.log(`プレビューボタンがクリックされました: ${pdfUrl}`);
        chrome.runtime.sendMessage({ type: 'PREVIEW_PDF', url: pdfUrl }, (response) => {
          if (chrome.runtime.lastError) {
            console.error("バックグラウンドへのメッセージ送信に失敗:", chrome.runtime.lastError.message);
          } else {
            console.log("バックグラウンドからの応答:", response);
          }
        });
      });

      // --- ▼▼▼ ここを変更 ▼▼▼ ---
      // リンク (<a>) のすぐ後ろに、プレビューボタンを直接挿入します。
      // <div> や <br> は使いません。
      link.parentNode.insertBefore(previewButton, link.nextSibling);
      // --- ▲▲▲ ここまで変更 ▲▲▲ ---

      wrapper.dataset.previewButtonAdded = 'true';
    }
  });
}

// ... (ページの読み込み待機と MutationObserver の部分は同じ) ...
window.addEventListener('load', addPreviewButtons);
const observer = new MutationObserver((mutations) => {
  setTimeout(addPreviewButtons, 500);
});
observer.observe(document.body, { childList: true, subtree: true });
addPreviewButtons();