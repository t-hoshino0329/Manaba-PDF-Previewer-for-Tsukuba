console.log("viewer.js (module) が読み込まれました。");

import * as pdfjsLib from '../lib/pdfjs/pdfjs-5.2.133-dist/build/pdf.mjs';

if (!pdfjsLib || !pdfjsLib.GlobalWorkerOptions) {
  console.error("PDF.js モジュールのインポートに失敗したか、形式が異なります。");
  throw new Error("PDF.js が見つかりません。");
}

pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('lib/pdfjs/pdfjs-5.2.133-dist/build/pdf.worker.mjs');

const pdfContainer = document.getElementById('pdf-container');

/**
 * ★★★ PDF を URL から fetch して表示する関数 ★★★
 * @param {string} pdfUrlToFetch - 表示したいPDFのURL
 */
async function renderPdfFromUrl(pdfUrlToFetch) {
  console.log("PDFのダウンロードを開始します:", pdfUrlToFetch);
  pdfContainer.innerHTML = '<p style="color: white; padding: 20px;">PDFをダウンロード中です...</p>';

  try {
    // --- ★★★ ここで fetch する ★★★ ---
    const response = await fetch(pdfUrlToFetch);
    if (!response.ok) {
      throw new Error(`PDFのダウンロードに失敗: ${response.statusText}`);
    }
    const pdfBlob = await response.blob(); // Blobとして取得
    console.log("PDFダウンロード成功:", pdfBlob);
    // --- ★★★ fetch 完了 ★★★ ---

    pdfContainer.innerHTML = '<p style="color: white; padding: 20px;">PDFを解析中です...</p>';

   const objectUrl = URL.createObjectURL(pdfBlob);
    console.log("Blob URL:", objectUrl);

    // ★★★ CMap 付きのオブジェクト形式で loadingTask を作成 ★★★
    const loadingTask = pdfjsLib.getDocument({
      url: objectUrl, // Blobから作ったURL
      cMapUrl: chrome.runtime.getURL('lib/pdfjs/pdfjs-5.2.133-dist/web/cmaps/'), // CMapフォルダへのパス
      cMapPacked: true // パック形式であることを示す
    });

    // ★★★ loadingTask.promise を使って pdfDoc を取得する ★★★
    const pdfDoc = await loadingTask.promise;
    console.log(`PDFの読み込み成功！ 全 ${pdfDoc.numPages} ページ`);

    URL.revokeObjectURL(objectUrl); // Blob URLの解放はここでもOK
    pdfContainer.innerHTML = '';

    for (let pageNum = 1; pageNum <= pdfDoc.numPages; pageNum++) {
      console.log(`${pageNum} ページ目を描画します...`);
      const page = await pdfDoc.getPage(pageNum);
      const viewport = page.getViewport({ scale: 1.5 });
      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      canvas.height = viewport.height;
      canvas.width = viewport.width;
      pdfContainer.appendChild(canvas);
      const renderContext = {
        canvasContext: context,
        viewport: viewport
      };
      await page.render(renderContext).promise;
      console.log(`${pageNum} ページ目の描画完了。`);
    }

  } catch (error) {
    console.error("PDFの表示中にエラーが発生しました:", error);
    pdfContainer.innerHTML = `<p style="color: red; padding: 20px;">PDFの表示に失敗しました: ${error.message}</p>`;
  }
}

// --- ページが読み込まれたら、バックグラウンドにPDFのURLを要求 ---
window.addEventListener('DOMContentLoaded', () => {
  console.log("ページの準備完了。バックグラウンドにPDFのURLを要求します。");

  chrome.runtime.sendMessage({ type: 'GET_PDF_DATA' }, (response) => {
    if (chrome.runtime.lastError) {
      console.error("バックグラウンドからの応答エラー:", chrome.runtime.lastError.message);
      pdfContainer.innerHTML = `<p style="color: red; padding: 20px;">バックグラウンドとの通信に失敗しました。</p>`;
      return;
    }

    // ★★★ URL を受け取って renderPdfFromUrl を呼び出す ★★★
    if (response && response.status === 'OK' && response.url) {
      renderPdfFromUrl(response.url);
    } else {
      console.error("バックグラウンドから有効なPDFのURLを受け取れませんでした:", response);
      pdfContainer.innerHTML = `<p style="color: red; padding: 20px;">PDFのURL取得に失敗しました: ${response ? response.message : '応答なし'}</p>`;
    }
  });
});