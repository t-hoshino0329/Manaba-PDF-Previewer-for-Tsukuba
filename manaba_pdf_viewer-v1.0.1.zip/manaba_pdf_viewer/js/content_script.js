console.log("PDFプレビュー拡張機能: コンテンツスクリプトが読み込まれました。");

/**
 * ページ内のPDFリンクを探してボタンを追加する関数
 */
function addPreviewButtons() {
  console.log("PDFリンクを探しています...");

  // --- <li> タグをすべて取得 ---
  const fileListItems = document.querySelectorAll('ul.attachments.attachmentsfile > li,div.queryv4,div.file');

  console.log(`${fileListItems.length} 個のリストアイテムが見つかりました。`);

  fileListItems.forEach(listItem => { // 変数名を listItem に変更
    // listItem の中にある <a> タグを（一つ）探す
    const link = listItem.querySelector('a');

    // --- a タグが見つかり、かつそれが PDF へのリンクだったら ---
    if (link && (link.href.endsWith('.pdf') || link.href.includes('pdf'))) {

      // --- すでにボタンが追加されていないかチェック (listItem に対して) ---
      if (listItem.dataset.previewButtonAdded) {
        return; // すでに追加済みなら、この listItem に対する処理はここで終了
      }

      console.log(`PDFリンク発見: ${link.href}`);

      const previewButton = document.createElement('button');
      previewButton.textContent = 'プレビュー';
      previewButton.className = 'pdf-preview-button';

      previewButton.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        const pdfUrl = link.href;
        console.log(`プレビューボタンがクリックされました: ${pdfUrl}`);
        chrome.runtime.sendMessage({ type: 'PREVIEW_PDF', url: pdfUrl }, (response) => {
          if (chrome.runtime.lastError) {
            console.error("バックグラウンドへのメッセージ送信に失敗:", chrome.runtime.lastError.message);
          } else {
            console.log("バックグラウンドからの応答:", response);
          }
        });
      });

      // --- ボタンを挿入する場所 ---
      // listItem の末尾にボタンを追加する (または link の後など、調整可能)
      listItem.appendChild(previewButton); 
      // もしリンクのすぐ横が良ければ、以前の link.parentNode.insertBefore(previewButton, link.nextSibling); でもOK
      // ただし、その場合は listItem の代わりに link を基準に重複チェックをするなど調整が必要

      // --- 追加済みの印をつける (listItem に対して) ---
      listItem.dataset.previewButtonAdded = 'true';

    }
  });
}


// ... (ページの読み込み待機と MutationObserver の部分は同じ) ...
window.addEventListener('load', addPreviewButtons);
const observer = new MutationObserver((mutations) => {
  setTimeout(addPreviewButtons, 500);
});
observer.observe(document.body, { childList: true, subtree: true });
addPreviewButtons();