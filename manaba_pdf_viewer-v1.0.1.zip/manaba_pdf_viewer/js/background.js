console.log("バックグラウンドスクリプト (Service Worker) が起動しました。");

// PDFの元のURLを一時的に保持する変数
let pdfOriginalUrlStore = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("メッセージを受信:", message.type);

  // --- コンテンツスクリプトから「プレビューして！」と頼まれた場合 ---
  if (message.type === 'PREVIEW_PDF' && message.url) {
    pdfOriginalUrlStore = message.url; // ★★★ 元のURLを保存 ★★★
    console.log(`PDFプレビューリクエストを受信: ${pdfOriginalUrlStore}`);

    const viewerUrl = chrome.runtime.getURL('html/pdf_viewer.html');
    chrome.tabs.create({ url: viewerUrl });

    // ★★★ Blobをフェッチせずに、すぐにOKを返す ★★★
    sendResponse({ status: "OK", message: "ビューアタブを開きます。" });
    // ★★★ ここでは非同期処理がないので return true は不要 ★★★
    return true;

  // --- ビューアタブから「PDFデータちょうだい」と頼まれた場合 ---
  } else if (message.type === 'GET_PDF_DATA') {
    console.log("ビューアからPDFデータのリクエストを受信しました。");
    if (pdfOriginalUrlStore) {
      console.log("保持していたURLを送信します:", pdfOriginalUrlStore);
      // ★★★ Blobの代わりにURLを送る ★★★
      sendResponse({ status: "OK", url: pdfOriginalUrlStore });
      pdfOriginalUrlStore = null; // 送信したらクリア
    } else {
      console.error("保持しているPDFのURLがありません。");
      sendResponse({ status: "Error", message: "PDFのURLが見つかりません。" });
    }
    // ★★★ ここも return true は不要 ★★★
    return true;
  }
});

console.log("メッセージリスナーを設定しました。");